from enum import IntEnum


class Color(IntEnum):
    BLACK = 30
    RED = 31
    GREEN = 32
    YELLOW = 33
    BLUE = 34
    MAGENTA = 35
    CYAN = 36
    WHITE = 37
    BACKGROUND = 10
    BRIGHT = 60
    NONE = 0
